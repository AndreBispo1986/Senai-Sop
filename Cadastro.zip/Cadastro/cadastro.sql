CREATE TABLE `cadastro`.`cadastros` ( 
	`id` INT(11) NOT NULL AUTO_INCREMENT ,
	`nome` VARCHAR(50) NOT NULL , 
	`email` VARCHAR(100) NOT NULL , 
	`senha` VARCHAR(20) NOT NULL , 
	PRIMARY KEY (`id`)
	) 
ENGINE = InnoDB;